//
//  AlarmGameView.swift
//  FinalProjectCrazyAlarm
//
//  Created by Ming Xia on 5/3/22.
//

import SwiftUI

struct AlarmGameView: View {
    var body: some View {
        
        NavigationView{
            ZStack{
                Color.yellow
                    .opacity(0.6)
                    .ignoresSafeArea()
                
                
                
                VStack{
                    
                    
                }
         
            }

        }

    }
}

struct AlarmGameView_Previews: PreviewProvider {
    static var previews: some View {
        AlarmGameView()
    }
}
